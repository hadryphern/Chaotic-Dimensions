// Regista os buffs e debuffs agrupados em Crystaline Potion Fortitude Buff.

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Buffs
{
	public sealed class CrystalinePotionFortitudeBuff : ModBuff
	{
		public override string Texture => $"Terraria/Images/Buff_{BuffID.Ironskin}";

		public override void Update(Player player, ref int buffIndex) {
			player.statDefense += 10;
		}
	}
}

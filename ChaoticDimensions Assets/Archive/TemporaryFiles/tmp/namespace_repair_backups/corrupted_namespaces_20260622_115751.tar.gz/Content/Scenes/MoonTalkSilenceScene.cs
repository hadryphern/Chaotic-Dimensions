using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using Terraria;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Scenes
{
	public sealed class MoonTalkSilenceScene : ModSceneEffect
	{
		public override int Music => 0;

		public override SceneEffectPriority Priority => SceneEffectPriority.BossHigh;

		public override float GetWeight(Player player) {
			return 1f;
		}

		public override bool IsSceneEffectActive(Player player) {
			return MoonTalkIntroSystem.IsActiveFor(player);
		}
	}
}

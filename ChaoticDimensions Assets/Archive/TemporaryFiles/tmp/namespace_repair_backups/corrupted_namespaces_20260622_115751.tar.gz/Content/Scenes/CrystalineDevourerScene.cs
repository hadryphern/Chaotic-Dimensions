// Ativa a musica e o ceu do Crystaline apenas durante o encontro.

using ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Bosses.CrystalineDevourer;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Scenes
{
	public sealed class CrystalineDevourerScene : ModSceneEffect
	{
		public override SceneEffectPriority Priority => SceneEffectPriority.BossHigh;

		public override int Music => MusicLoader.GetMusicSlot(Mod, "Sounds/Music/CrystalineDevour");

		// Confirma se esta cena deve ficar ativa para o jogador.
		public override bool IsSceneEffectActive(Player player) {
			if (!player.active || player.dead) {
				return false;
			}

			return CrystalineDevourerIntroSystem.IsActive ||
				(CrystalineDevourerArenaSystem.HasAnyLivingPlayers() && NPC.AnyNPCs(ModContent.NPCType<CrystalineDevourerHead>()));
		}

		// Liga ou desliga o filtro e o ceu desta cena.
		public override void SpecialVisuals(Player player, bool isActive) {
			if (!Main.dedServ) {
				player.ManageSpecialBiomeVisuals(ChaoticDimensions.tmp.comment_backups.20260619_215050.CrystalineDevourerSkyKey, isActive);
				if (isActive) {
					SkyManager.Instance.Activate(ChaoticDimensions.tmp.comment_backups.20260619_215050.CrystalineDevourerSkyKey, player.Center);
				}
				else {
					SkyManager.Instance.Deactivate(ChaoticDimensions.tmp.comment_backups.20260619_215050.CrystalineDevourerSkyKey);
				}
			}
		}
	}
}

// Reune valores, receitas e efeitos dos itens de Crystaline Tear.

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Items.Materials
{
	public sealed class CrystalineTear : ModItem
	{
		// Define os valores iniciais usados pelo tModLoader.
		public override void SetDefaults() {
			Item.width = 26;
			Item.height = 26;
			Item.maxStack = Item.CommonMaxStack;
			Item.value = Item.buyPrice(gold: 2);
			Item.rare = ItemRarityID.Purple;
			Item.material = true;
		}
	}
}

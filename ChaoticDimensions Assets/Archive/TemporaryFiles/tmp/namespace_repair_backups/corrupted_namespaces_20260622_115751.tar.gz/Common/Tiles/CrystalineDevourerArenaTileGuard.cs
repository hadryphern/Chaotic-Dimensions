// Define os blocos, colocacao e interacoes de Crystaline Devourer Arena Tile Guard.

using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Common.Tiles
{
	public sealed class CrystalineDevourerArenaTileGuard : GlobalTile
	{
		// Controla se o tile pode ser removido neste contexto.
		public override bool CanKillTile(int i, int j, int type, ref bool blockDamaged) {
			if (CrystalineDevourerArenaSystem.ProtectsTile(i, j, type)) {
				return false;
			}

			return base.CanKillTile(i, j, type, ref blockDamaged);
		}

		// Protege este tile contra explosoes quando necessario.
		public override bool CanExplode(int i, int j, int type) {
			if (CrystalineDevourerArenaSystem.ProtectsTile(i, j, type)) {
				return false;
			}

			return base.CanExplode(i, j, type);
		}
	}
}

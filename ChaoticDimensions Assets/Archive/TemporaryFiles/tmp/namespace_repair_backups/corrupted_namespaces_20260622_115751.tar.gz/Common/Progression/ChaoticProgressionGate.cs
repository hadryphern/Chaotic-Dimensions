// Define regras e etapas de progressao relacionadas com Chaotic Progression Gate.

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.Common.Progression
{
	public enum ChaoticProgressionGate
	{
		Anytime,
		PostKingSlime,
		PostEyeOfCthulhu,
		PostEvilBoss,
		PostQueenBee,
		PostSkeletron,
		PostWallOfFlesh,
		PostAnyMech,
		PostAllMechs,
		PostPlantera,
		PostGolem,
		PostCultist,
		PostMoonLord,
		PostMonthra,
		PostCrystalineDevourer,
		PostKraken,
		PostChaoticApexOne,
		PostChaoticApexTwo,
		PostChaoticApexThree,
		PostChaoticApexTrio
	}
}

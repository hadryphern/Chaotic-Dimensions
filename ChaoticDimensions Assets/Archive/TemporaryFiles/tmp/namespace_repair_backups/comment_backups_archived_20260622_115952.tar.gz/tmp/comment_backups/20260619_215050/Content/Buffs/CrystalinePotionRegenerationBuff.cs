using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.20260619_215050.Content.Buffs
{
	public sealed class CrystalinePotionRegenerationBuff : ModBuff
	{
		public override string Texture => $"Terraria/Images/Buff_{BuffID.Regeneration}";

		public override void Update(Player player, ref int buffIndex) {
			player.lifeRegen += 18;
		}
	}
}

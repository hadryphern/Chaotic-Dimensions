using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Bosses.Monthra;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.20260619_215050.Content.Scenes
{
	public sealed class MonthraScene : ModSceneEffect
	{
		public override SceneEffectPriority Priority => SceneEffectPriority.BossHigh;

		public override int Music => MusicLoader.GetMusicSlot(Mod, "Sounds/Music/Monthra");

		public override bool IsSceneEffectActive(Player player) {
			if (!player.active || player.dead) {
				return false;
			}

			return MonthraIntroSystem.IsActive || NPC.AnyNPCs(ModContent.NPCType<MonthraBoss>());
		}

		public override void SpecialVisuals(Player player, bool isActive) {
			if (Main.dedServ) {
				return;
			}

			player.ManageSpecialBiomeVisuals(ChaoticDimensions.tmp.comment_backups.20260619_215050.MonthraGalaxySkyKey, isActive);
			if (isActive) {
				SkyManager.Instance.Activate(ChaoticDimensions.tmp.comment_backups.20260619_215050.MonthraGalaxySkyKey, player.Center);
			}
			else {
				SkyManager.Instance.Deactivate(ChaoticDimensions.tmp.comment_backups.20260619_215050.MonthraGalaxySkyKey);
			}
		}
	}
}

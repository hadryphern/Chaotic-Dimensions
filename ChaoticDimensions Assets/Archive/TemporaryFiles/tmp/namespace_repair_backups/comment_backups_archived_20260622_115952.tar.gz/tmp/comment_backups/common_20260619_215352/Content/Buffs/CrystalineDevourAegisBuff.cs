// Regista os buffs e debuffs agrupados em Crystaline Devour Aegis Buff.

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Content.Buffs
{
	public sealed class CrystalineDevourAegisBuff : ModBuff
	{
		public override string Texture => $"Terraria/Images/Buff_{BuffID.Shine}";

		public override void SetStaticDefaults() {
			Main.buffNoSave[Type] = true;
			Main.buffNoTimeDisplay[Type] = false;
		}
	}
}

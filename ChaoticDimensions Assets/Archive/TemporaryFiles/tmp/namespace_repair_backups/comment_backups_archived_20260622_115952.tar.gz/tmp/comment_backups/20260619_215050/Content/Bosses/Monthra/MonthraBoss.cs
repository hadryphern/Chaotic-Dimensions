using System.IO;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Items.Materials;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.NPCs.Monthra;
using ChaoticDimensions.tmp.comment_backups.20260619_215050.Content.Projectiles.Hostile;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.20260619_215050.Content.Bosses.Monthra
{
	internal enum MonthraAttackState
	{
		HoverVolley,
		DashChain,
		PrismaticPursuit,
		LightLattice,
		SolarSpiral,
		ButterflySwarm
	}

	[AutoloadBossHead]
	public sealed class MonthraBoss : ModNPC
	{
		private const float DrawScale = 0.82f;
		private ref float State => ref NPC.ai[0];
		private ref float StateTimer => ref NPC.ai[1];
		private ref float HoverSide => ref NPC.ai[2];

		private float LifeRatio => NPC.lifeMax <= 0 ? 1f : NPC.life / (float)NPC.lifeMax;
		private float Rage => 1f - LifeRatio;
		private bool PhaseTwo => LifeRatio < 0.5f;
		private bool FinalPhase => LifeRatio < 0.2f;

		public override void SetStaticDefaults() {
			Main.npcFrameCount[Type] = 12;
			NPCID.Sets.BossBestiaryPriority.Add(Type);
			NPCID.Sets.MustAlwaysDraw[Type] = true;
		}

		public override void SetDefaults() {
			NPC.width = 520;
			NPC.height = 400;
			NPC.damage = 270;
			NPC.defense = 80;
			NPC.lifeMax = 5000000;
			NPC.knockBackResist = 0f;
			NPC.value = Item.buyPrice(platinum: 1);
			NPC.npcSlots = 16f;
			NPC.boss = true;
			NPC.aiStyle = -1;
			NPC.noGravity = true;
			NPC.noTileCollide = true;
			NPC.netAlways = true;
			Music = 0;
		}

		public override void ApplyDifficultyAndPlayerScaling(int numPlayers, float balance, float bossAdjustment) {
			NPC.lifeMax = (int)(NPC.lifeMax * balance * 0.82f);
			NPC.damage = (int)(NPC.damage * 0.92f);
		}

		public override void AI() {
			if (!TargetOrDespawn()) {
				return;
			}

			if (HoverSide == 0f) {
				HoverSide = Main.rand.NextBool() ? 1f : -1f;
			}

			Player player = Main.player[NPC.target];
			StateTimer++;
			NPC.damage = (int)MathHelper.Lerp(270f, 350f, Rage);

			switch ((MonthraAttackState)(int)State) {
				case MonthraAttackState.DashChain:
					RunDashChain(player);
					break;
				case MonthraAttackState.PrismaticPursuit:
					RunPrismaticPursuit(player);
					break;
				case MonthraAttackState.LightLattice:
					RunLightLattice(player);
					break;
				case MonthraAttackState.SolarSpiral:
					RunSolarSpiral(player);
					break;
				case MonthraAttackState.ButterflySwarm:
					RunButterflySwarm(player);
					break;
				default:
					RunHoverVolley(player);
					break;
			}

			NPC.spriteDirection = NPC.velocity.X >= 0f ? -1 : 1;
			NPC.rotation = MathHelper.Clamp(NPC.velocity.X * 0.009f, -0.36f, 0.36f);
			Lighting.AddLight(NPC.Center, 0.28f, 0.06f, 0.24f);
		}

		private bool TargetOrDespawn() {
			NPC.TargetClosest(false);
			if (NPC.target >= 0 && NPC.target < Main.maxPlayers) {
				Player player = Main.player[NPC.target];
				if (player.active && !player.dead) {
					return true;
				}
			}

			NPC.velocity.Y -= 0.4f;
			NPC.EncourageDespawn(10);
			return false;
		}

		private int Duration(int baseDuration) {
			return (int)MathHelper.Lerp(baseDuration, baseDuration * 0.62f, Rage);
		}

		private void RunHoverVolley(Player player) {
			Vector2 offset = new(330f * HoverSide, -245f + (float)System.Math.Sin(StateTimer * 0.095f) * 55f);
			SteerTowards(player.Center + offset, 20f + Rage * 13f, 0.1f + Rage * 0.045f);
			int interval = System.Math.Max(18, (int)MathHelper.Lerp(38f, 19f, Rage));
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer > 16f && (int)StateTimer % interval == 0) {
				FireRegularVolley(player, PhaseTwo ? 7 : 5, 14f + Rage * 5f, 24f + Rage * 12f, PhaseTwo ? 195 : 160);
			}

			if (StateTimer >= Duration(155)) {
				SwitchState(MonthraAttackState.DashChain);
			}
		}

		private void RunDashChain(Player player) {
			int cycle = System.Math.Max(23, (int)MathHelper.Lerp(38f, 24f, Rage));
			int tick = (int)StateTimer % cycle;
			if (tick < 11) {
				Vector2 staging = player.Center + new Vector2(-HoverSide * 560f, -120f + (float)System.Math.Sin(StateTimer * 0.12f) * 70f);
				SteerTowards(staging, 25f + Rage * 12f, 0.16f);
			}
			else if (tick == 11) {
				Vector2 predicted = player.Center + player.velocity * MathHelper.Lerp(10f, 18f, Rage);
				NPC.velocity = (predicted - NPC.Center).SafeNormalize(Vector2.UnitX) * MathHelper.Lerp(48f, 72f, Rage);
				SoundEngine.PlaySound(SoundID.Item74 with { Pitch = 0.18f, Volume = 0.9f }, NPC.Center);
				NPC.netUpdate = true;
			}
			else if (tick > cycle - 8) {
				NPC.velocity *= 0.86f;
			}

			if (Main.netMode != NetmodeID.MultiplayerClient && tick == cycle - 6) {
				FireRegularVolley(player, PhaseTwo ? 5 : 3, 15f + Rage * 4f, 20f, PhaseTwo ? 205 : 170);
			}

			if (StateTimer >= Duration(210)) {
				HoverSide *= -1f;
				SwitchState(MonthraAttackState.PrismaticPursuit);
			}
		}

		private void RunPrismaticPursuit(Player player) {
			Vector2 offset = new(-HoverSide * 390f, -320f);
			SteerTowards(player.Center + offset, 22f + Rage * 12f, 0.11f);
			int interval = FinalPhase ? 58 : PhaseTwo ? 72 : 88;
			if (Main.netMode != NetmodeID.MultiplayerClient && (StateTimer == 24f || (StateTimer > 24f && (int)(StateTimer - 24f) % interval == 0))) {
				SpawnPrismaticFan(player);
			}

			if (StateTimer >= Duration(205)) {
				SwitchState(MonthraAttackState.LightLattice);
			}
		}

		private void RunLightLattice(Player player) {
			Vector2 watch = player.Center + new Vector2(HoverSide * 430f, -360f);
			SteerTowards(watch, 18f + Rage * 9f, 0.09f);
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer == 30f) {
				SpawnLightLattice(player);
			}
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer > 65f && (int)StateTimer % 48 == 0) {
				FireHomingShot(player, PhaseTwo ? 225 : 185);
			}
			if (StateTimer >= Duration(190)) {
				SwitchState(MonthraAttackState.SolarSpiral);
			}
		}

		private void RunSolarSpiral(Player player) {
			Vector2 anchor = player.Center + new Vector2(0f, -330f);
			SteerTowards(anchor, 17f + Rage * 6f, 0.12f);
			NPC.velocity *= 0.94f;

			int interval = FinalPhase ? 7 : PhaseTwo ? 8 : 10;
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer >= 28f && StateTimer <= 225f && (int)StateTimer % interval == 0) {
				int arms = FinalPhase ? 4 : 3;
				float baseAngle = StateTimer * (0.115f + Rage * 0.035f);
				for (int i = 0; i < arms; i++) {
					float angle = baseAngle + MathHelper.TwoPi * i / arms;
					Vector2 direction = angle.ToRotationVector2();
					Vector2 origin = NPC.Center + direction * 105f;
					Vector2 velocity = direction * (11.5f + Rage * 4.5f);
					Projectile.NewProjectile(NPC.GetSource_FromAI(), origin, velocity, ModContent.ProjectileType<MonthraFireball>(), PhaseTwo ? 205 : 170, 0f, Main.myPlayer);
				}
			}

			if (StateTimer >= Duration(255)) {
				SwitchState(MonthraAttackState.ButterflySwarm);
			}
		}

		private void RunButterflySwarm(Player player) {
			Vector2 orbit = new Vector2(410f, 0f).RotatedBy(StateTimer * (0.045f + Rage * 0.025f) * HoverSide);
			SteerTowards(player.Center + orbit, 23f + Rage * 14f, 0.12f);
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer == 20f) {
				SpawnMothSwarm(FinalPhase ? 12 : PhaseTwo ? 10 : 8);
			}
			if (Main.netMode != NetmodeID.MultiplayerClient && StateTimer > 40f && (int)StateTimer % 42 == 0) {
				FireHomingShot(player, PhaseTwo ? 220 : 180);
			}
			if (StateTimer >= Duration(185)) {
				HoverSide *= -1f;
				SwitchState(MonthraAttackState.HoverVolley);
			}
		}

		private void SpawnPrismaticFan(Player player) {
			Vector2 predicted = player.Center + player.velocity * (14f + Rage * 8f);
			float centerAngle = (predicted - NPC.Center).ToRotation();
			int count = FinalPhase ? 11 : PhaseTwo ? 9 : 7;
			float spread = FinalPhase ? 0.7f : 0.56f;
			for (int i = 0; i < count; i++) {
				float t = count == 1 ? 0.5f : i / (float)(count - 1);
				float angle = centerAngle + MathHelper.Lerp(-spread, spread, t);
				float turn = MathHelper.Lerp(-0.0028f, 0.0028f, t) * (1f + Rage * 0.5f);
				Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, new Vector2(turn, 0f), ModContent.ProjectileType<MonthraPrismaticRay>(), PhaseTwo ? 245 : 205, 0f, Main.myPlayer, angle, 2600f);
			}
			SoundEngine.PlaySound(SoundID.Item29 with { Pitch = 0.34f, Volume = 1.05f }, NPC.Center);
		}

		private void SpawnLightLattice(Player player) {
			Vector2 safe = player.Center + player.velocity * 16f + Main.rand.NextVector2Circular(90f, 55f);
			const float safeWidth = 300f;
			const float safeHeight = 240f;
			int rowsPerSide = FinalPhase ? 6 : 5;
			for (int side = -1; side <= 1; side += 2) {
				for (int i = 0; i < rowsPerSide; i++) {
					float y = safe.Y + side * (safeHeight * 0.5f + 95f + i * 105f);
					SpawnLatticeRay(new Vector2(safe.X, y), 0f);
					float x = safe.X + side * (safeWidth * 0.5f + 105f + i * 115f);
					SpawnLatticeRay(new Vector2(x, safe.Y), MathHelper.PiOver2);
				}
			}
			SoundEngine.PlaySound(SoundID.Item162 with { Pitch = 0.12f, Volume = 1.1f }, safe);
		}

		private void SpawnLatticeRay(Vector2 center, float rotation) {
			Projectile.NewProjectile(NPC.GetSource_FromAI(), center, Vector2.Zero, ModContent.ProjectileType<MonthraPrismaticRay>(), PhaseTwo ? 260 : 220, 0f, Main.myPlayer, rotation, -1900f);
		}

		private void SpawnMothSwarm(int count) {
			for (int i = 0; i < count; i++) {
				Vector2 spawn = NPC.Center + Main.rand.NextVector2CircularEdge(210f, 150f);
				int index = NPC.NewNPC(NPC.GetSource_FromAI(), (int)spawn.X, (int)spawn.Y, ModContent.NPCType<MonthraMothMinion>(), ai0: NPC.whoAmI);
				if (index >= 0 && index < Main.maxNPCs) {
					Main.npc[index].netUpdate = true;
				}
			}
		}

		private void FireRegularVolley(Player player, int count, float speed, float spreadDegrees, int damage) {
			Vector2 direction = (player.Center + player.velocity * 8f - NPC.Center).SafeNormalize(Vector2.UnitY);
			for (int i = 0; i < count; i++) {
				float t = count == 1 ? 0.5f : i / (float)(count - 1);
				Vector2 velocity = direction.RotatedBy(MathHelper.ToRadians(MathHelper.Lerp(-spreadDegrees, spreadDegrees, t))) * speed;
				Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, velocity, ModContent.ProjectileType<MonthraFireball>(), damage, 0f, Main.myPlayer);
			}
			SoundEngine.PlaySound(SoundID.Item20 with { Pitch = 0.18f, Volume = 0.9f }, NPC.Center);
		}

		private void FireHomingShot(Player player, int damage) {
			Vector2 direction = (player.Center - NPC.Center).SafeNormalize(Vector2.UnitY);
			Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, direction * 11f, ModContent.ProjectileType<MonthraFireballHoming>(), damage, 0f, Main.myPlayer);
		}

		private void SteerTowards(Vector2 target, float speed, float turnRate) {
			Vector2 desired = (target - NPC.Center).SafeNormalize(Vector2.UnitY) * speed;
			NPC.velocity = Vector2.Lerp(NPC.velocity, desired, turnRate);
			if (NPC.velocity.Length() > speed) {
				NPC.velocity = NPC.velocity.SafeNormalize(Vector2.UnitY) * speed;
			}
		}

		private void SwitchState(MonthraAttackState next) {
			State = (float)next;
			StateTimer = 0f;
			NPC.netUpdate = true;
		}

		public override void ModifyNPCLoot(NPCLoot npcLoot) {
			npcLoot.Add(ItemDropRule.Common(ModContent.ItemType<MonthraScale>(), 1, 55, 75));
			npcLoot.Add(ItemDropRule.Common(ItemID.SuperHealingPotion, 1, 8, 14));
		}

		public override void FindFrame(int frameHeight) {
			NPC.frameCounter++;
			int frameDelay = FinalPhase ? 2 : PhaseTwo ? 3 : 4;
			if (NPC.frameCounter >= frameDelay) {
				NPC.frameCounter = 0;
				NPC.frame.Y = (NPC.frame.Y + frameHeight) % (frameHeight * Main.npcFrameCount[Type]);
			}
		}

		public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor) {
			Texture2D texture = TextureAssets.Npc[Type].Value;
			int frameHeight = texture.Height / Main.npcFrameCount[Type];
			Rectangle source = new(0, NPC.frame.Y, texture.Width, frameHeight);
			Vector2 origin = source.Size() * 0.5f;
			SpriteEffects effects = NPC.spriteDirection == 1 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;
			spriteBatch.Draw(texture, NPC.Center - screenPos, source, NPC.GetAlpha(drawColor), NPC.rotation, origin, DrawScale, effects, 0f);
			return false;
		}

		public override void SendExtraAI(BinaryWriter writer) => writer.Write(HoverSide);
		public override void ReceiveExtraAI(BinaryReader reader) => HoverSide = reader.ReadSingle();

		public override void OnKill() {
			NPC.SetEventFlagCleared(ref ChaoticDownedBossSystem.downedMonthra, -1);
		}

		public override bool CheckActive() => false;
	}
}

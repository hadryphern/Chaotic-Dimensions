// Regista os buffs e debuffs agrupados em Crystaline Rush Buff.

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Content.Buffs
{
	public sealed class CrystalineRushBuff : ModBuff
	{
		public override string Texture => $"Terraria/Images/Buff_{BuffID.Regeneration}";

		public override void SetStaticDefaults() {
			Main.buffNoTimeDisplay[Type] = false;
		}

		public override void Update(Player player, ref int buffIndex) {
			player.lifeRegen += 8;
			player.moveSpeed += 0.12f;
		}
	}
}

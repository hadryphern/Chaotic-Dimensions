// Guarda no mundo quais bosses do mod ja foram derrotados.

using System.IO;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems
{
	public sealed class ChaoticDownedBossSystem : ModSystem
	{
		public static bool downedMonthra;
		public static bool downedChaoticApexOne;
		public static bool downedChaoticApexTwo;
		public static bool downedChaoticApexThree;
		public static bool downedCrystalineDevourer;
		public static bool downedKraken;

		public override void ClearWorld() {
			downedMonthra = false;
			downedChaoticApexOne = false;
			downedChaoticApexTwo = false;
			downedChaoticApexThree = false;
			downedCrystalineDevourer = false;
			downedKraken = false;
		}

		public override void SaveWorldData(TagCompound tag) {
			if (downedMonthra) {
				tag["downedMonthra"] = true;
			}

			if (downedChaoticApexOne) {
				tag["downedChaoticApexOne"] = true;
			}

			if (downedChaoticApexTwo) {
				tag["downedChaoticApexTwo"] = true;
			}

			if (downedChaoticApexThree) {
				tag["downedChaoticApexThree"] = true;
			}

			if (downedCrystalineDevourer) {
				tag["downedCrystalineDevourer"] = true;
			}

			if (downedKraken) {
				tag["downedKraken"] = true;
			}
		}

		public override void LoadWorldData(TagCompound tag) {
			downedMonthra = tag.ContainsKey("downedMonthra");
			downedChaoticApexOne = tag.ContainsKey("downedChaoticApexOne");
			downedChaoticApexTwo = tag.ContainsKey("downedChaoticApexTwo");
			downedChaoticApexThree = tag.ContainsKey("downedChaoticApexThree");
			downedCrystalineDevourer = tag.ContainsKey("downedCrystalineDevourer");
			downedKraken = tag.ContainsKey("downedKraken");
		}

		public override void NetSend(BinaryWriter writer) {
			writer.WriteFlags(
				downedMonthra,
				downedChaoticApexOne,
				downedChaoticApexTwo,
				downedChaoticApexThree,
				downedCrystalineDevourer,
				downedKraken);
		}

		public override void NetReceive(BinaryReader reader) {
			reader.ReadFlags(
				out downedMonthra,
				out downedChaoticApexOne,
				out downedChaoticApexTwo,
				out downedChaoticApexThree,
				out downedCrystalineDevourer,
				out downedKraken);
		}
	}
}

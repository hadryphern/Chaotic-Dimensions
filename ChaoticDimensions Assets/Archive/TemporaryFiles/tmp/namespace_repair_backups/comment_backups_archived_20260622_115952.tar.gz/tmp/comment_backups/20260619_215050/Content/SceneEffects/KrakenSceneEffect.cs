using ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.common_20260619_215352.Common.Systems;
using Terraria;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.20260619_215050.Content.SceneEffects
{
	public class KrakenSceneEffect : ModSceneEffect
	{
		public override int Music => MusicLoader.GetMusicSlot(Mod, "Assets/Music/KrakenTheme");

		public override SceneEffectPriority Priority => SceneEffectPriority.BossHigh;

		public override bool IsSceneEffectActive(Player player) {
			KrakenEventSystem system = KrakenEventSystem.Instance;
			return system.Active;
		}

		public override void SpecialVisuals(Player player, bool isActive) {
			if (Main.dedServ) {
				return;
			}

			player.ManageSpecialBiomeVisuals("MoonLord", isActive, player.Center);
		}
	}
}

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace ChaoticDimensions.tmp.comment_backups.20260619_215050.tmp.comment_backups.20260619_215050.Content.Projectiles.Hostile
{
	public sealed class MonthraPrismaticRay : ModProjectile
	{
		private const int TelegraphTime = 62;
		private const int ActiveTime = 34;
		private int Age => (int)Projectile.localAI[0];
		private float BeamLength => System.Math.Abs(Projectile.ai[1]);
		private bool Symmetric => Projectile.ai[1] < 0f;
		private bool Active => Age >= TelegraphTime && Age < TelegraphTime + ActiveTime;

		public override string Texture => "ChaoticDimensions/Content/Projectiles/Hostile/MonthraFireball";

		public override void SetDefaults() {
			Projectile.width = 10;
			Projectile.height = 10;
			Projectile.hostile = true;
			Projectile.tileCollide = false;
			Projectile.ignoreWater = true;
			Projectile.penetrate = -1;
			Projectile.timeLeft = 128;
		}

		public override bool ShouldUpdatePosition() => false;
		public override bool? CanDamage() => Active;

		public override void AI() {
			Projectile.localAI[0]++;
			Projectile.ai[0] += Projectile.velocity.X;
			if (Projectile.localAI[0] == TelegraphTime) {
				Projectile.netUpdate = true;
			}
		}

		private void GetLine(out Vector2 start, out Vector2 end) {
			Vector2 direction = Projectile.ai[0].ToRotationVector2();
			if (Symmetric) {
				start = Projectile.Center - direction * BeamLength;
				end = Projectile.Center + direction * BeamLength;
			}
			else {
				start = Projectile.Center;
				end = Projectile.Center + direction * BeamLength;
			}
		}

		public override bool? Colliding(Rectangle projHitbox, Rectangle targetHitbox) {
			GetLine(out Vector2 start, out Vector2 end);
			float collisionPoint = 0f;
			return Collision.CheckAABBvLineCollision(targetHitbox.TopLeft(), targetHitbox.Size(), start, end, Active ? 9f : 3f, ref collisionPoint);
		}

		public override bool PreDraw(ref Color lightColor) {
			GetLine(out Vector2 worldStart, out Vector2 worldEnd);
			Vector2 start = worldStart - Main.screenPosition;
			Vector2 end = worldEnd - Main.screenPosition;
			float telegraph = Utils.GetLerpValue(0f, TelegraphTime, Age, true);
			float pulse = 0.68f + 0.32f * (float)System.Math.Sin(Main.GlobalTimeWrappedHourly * 13f + Projectile.identity);
			Color glow = Active ? new Color(255, 75, 222) * 0.48f : new Color(218, 62, 195) * (0.12f + telegraph * pulse * 0.13f);
			Color core = Active ? new Color(255, 232, 252) * 0.95f : new Color(255, 172, 239) * (0.28f + telegraph * 0.24f);
			DrawLine(start, end, glow, Active ? 18f : 7f);
			DrawLine(start, end, core, Active ? 4f : 2f);
			return false;
		}

		private static void DrawLine(Vector2 start, Vector2 end, Color color, float width) {
			Texture2D pixel = TextureAssets.MagicPixel.Value;
			Vector2 edge = end - start;
			Main.EntitySpriteDraw(pixel, start, null, color, edge.ToRotation(), Vector2.Zero, new Vector2(edge.Length(), width), SpriteEffects.None, 0);
		}
	}
}
